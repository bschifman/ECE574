Kevin Curtis:	 kevincurtis
Ben Schifman:	 bschifman

Vivado 2016.2

xc7a100tcsg324-1
xc7a100tfgg676-1 (for larger I/O)


To calculate the critical path we first set the module of the circuit we wanted to analyze as the top module.

We then clicked the run implementation. After it is implemented we then click on Report Timing Summary. Then we check the largest unconstrained path in the timing summary to find the largest time delay.


